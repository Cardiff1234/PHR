class MiscDemoController < ApplicationController
  def index
  end
end
