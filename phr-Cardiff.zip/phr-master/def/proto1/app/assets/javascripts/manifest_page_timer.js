//= require prototype
//= require testpanel
//= require browser_detect
//= require taffy
