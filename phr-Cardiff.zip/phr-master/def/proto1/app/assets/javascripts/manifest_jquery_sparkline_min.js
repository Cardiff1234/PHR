//= require jquery/jquery.min
//= require jquery/jquery.sparkline.min
//= require jquery/jquery.flot.min
//= require jquery/jquery.flot.crosshair.min
//= require jquery/jquery.flot.selection.min
