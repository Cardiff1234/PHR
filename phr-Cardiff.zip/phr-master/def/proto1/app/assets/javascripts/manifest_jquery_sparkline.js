//= require jquery/jquery.sparkline
//= require jquery/jquery.flot
//= require jquery/jquery.flot.crosshair
//= require jquery/jquery.flot.selection
