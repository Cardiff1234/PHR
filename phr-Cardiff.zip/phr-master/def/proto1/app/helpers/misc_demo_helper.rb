module MiscDemoHelper
end
