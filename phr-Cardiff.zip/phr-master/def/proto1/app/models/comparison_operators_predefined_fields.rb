class ComparisonOperatorsPredefinedFields < ActiveRecord::Base
end
