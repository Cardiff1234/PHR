class FieldExpression < ActiveRecord::Base
end
