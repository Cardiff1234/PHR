class DataEdit < ActiveRecord::Base
end
