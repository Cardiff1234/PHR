class FormsRuleSet < ActiveRecord::Base
end
