class FormTableMapping < ActiveRecord::Base
end
