class TextTemplate < ActiveRecord::Base
end
