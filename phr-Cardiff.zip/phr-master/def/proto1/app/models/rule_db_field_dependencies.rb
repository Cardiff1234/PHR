class RuleDbFieldDependencies < ActiveRecord::Base
end
