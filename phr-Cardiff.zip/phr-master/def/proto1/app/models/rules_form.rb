# A model class definition for the rules_forms join table, so we can use
# ActiveRecord for information about its columns.

class RulesForm < ActiveRecord::Base
end

