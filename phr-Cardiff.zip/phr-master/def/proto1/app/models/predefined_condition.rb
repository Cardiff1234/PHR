class PredefinedCondition < ActiveRecord::Base
  extend HasShortList

end
