class RuleFieldDependency < ActiveRecord::Base
end
