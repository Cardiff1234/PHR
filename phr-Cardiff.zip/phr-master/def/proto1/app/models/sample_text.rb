class SampleText < ActiveRecord::Base
end
