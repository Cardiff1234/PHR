class FieldValidationCondition < ActiveRecord::Base
  belongs_to :field_validation
end
