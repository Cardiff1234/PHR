class MplusDrug < ActiveRecord::Base
end
