class GopherTermsMplusHt < ActiveRecord::Base
end
