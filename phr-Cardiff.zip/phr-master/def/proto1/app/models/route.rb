class Route < ActiveRecord::Base
end
