class ExpressionCondition < ActiveRecord::Base
  extend HasShortList

end
