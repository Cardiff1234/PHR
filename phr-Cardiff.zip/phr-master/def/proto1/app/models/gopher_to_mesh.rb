class GopherToMesh < ActiveRecord::Base
end
