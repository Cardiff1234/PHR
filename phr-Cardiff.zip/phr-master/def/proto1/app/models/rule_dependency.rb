class RuleDependency < ActiveRecord::Base
end
