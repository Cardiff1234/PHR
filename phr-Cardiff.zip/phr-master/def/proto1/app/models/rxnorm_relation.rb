class RxnormRelation < ActiveRecord::Base
end
