class UserPreference < ActiveRecord::Base
  belongs_to :users
  
end # user_preference
