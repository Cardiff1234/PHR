class RxhubFrequency < ActiveRecord::Base
end
