class FieldCondition < ActiveRecord::Base
end
