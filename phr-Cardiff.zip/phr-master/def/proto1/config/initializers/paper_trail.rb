PaperTrail.config.track_associations = false
