ActionDispatch::Request::DEFAULT_PARSERS.delete(Mime[:xml])
ActionDispatch::Request::DEFAULT_PARSERS.delete(Mime[:json])